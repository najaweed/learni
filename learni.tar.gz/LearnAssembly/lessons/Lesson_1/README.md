create external funtion for system output and exit to get a clear code.
change x64_intel template into 2 files for print and exit
