#include<stdio.h>


int main() {
	printf("HELL\n");
	return 0 ;
}
