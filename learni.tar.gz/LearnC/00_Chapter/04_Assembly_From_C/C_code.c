#include <stdio.h>
#include <stdlib.h>
#include "asm_headers.h"


int main(void) {
	int res;

	puts("!!!Hello World!!!"); /* prints !!!Hello World!!! */
	int x0=11;
	int x1=22;
	int x2=44;

	res = asmMain(x0, x1, x2);

	printf("%d\n",res);
	
	puts("!!!Hello World!!!");
	return EXIT_SUCCESS;
}
