#include <stdio.h>


int dummy_print(){
    printf("HELL\n");
    return 0;
}