#include "header.h"

int main (){
    dummy_print();
    return 0;
}