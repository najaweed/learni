#include <stdio.h>


int dummy_print(){
    printf("HELL YAaaaaaaa\n");
    return 0;
}
