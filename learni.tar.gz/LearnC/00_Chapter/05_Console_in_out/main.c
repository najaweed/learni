#include <stdio.h>
//#include "functions.h"

int main (){

    int hell_num ;
    printf("HELL NUMBER? : \n");
    scanf("%d",&hell_num);
    printf("your HELL num is : %d \n",hell_num);

    return 0;
}