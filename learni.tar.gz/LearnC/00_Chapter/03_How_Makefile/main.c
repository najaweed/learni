#include "functions.h"

int main (){
    int x = 11;
    dummy_print();
    return 0;
}