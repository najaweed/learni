#include<stdio.h>
#include "functions.h"

int main (){
    int x = 11;
    if (x == 1 ){
        puts("x is 1");
    } else if (x == 2){
        puts("x is 2 ");
    } else{
        puts("x not");
    }
    
    return 0;
}