#include<stdio.h>
#include "functions.h"

int main (){
    printf("HELL YA\n");

    int x = 0;
    while (x <=10){
        x +=1;
        printf("x =  %d \n",x);

    };

    // Do while 
    do {
        printf("x =  %d \n",x);
        
    } while( x <9);

    return 0;
}