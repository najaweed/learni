#include<stdio.h>
#include "functions.h"

int main (){

    int statement  = 1;

    switch (statement)
    {
    case 1:
        printf("case 1 \n");
        break;
    
    default:
        printf("case defult \n");
        break;
    
    }
    return 0;
}