#include<stdio.h>
#include "functions.h"

int main (){
    printf("HELL YA\n");
    for (int i;i<10;++i){
        printf("%d \n",i);
    }
    return 0;
}