#include<stdio.h>
#include "functions.h"

void fun_1(int* p_x){
  // deref p_x and add 1 
  *p_x +=1;
}

int main (){
    int x = 2;
    printf(" x = %d \n",x);
    fun_1(&x);
    printf(" x = %d \n",x);

    return 0;
}
