#include<stdio.h>
#include "functions.h"

int main (){
  long a[4];
  for(int i; i <4; i+=8){
    // address of element of array
    printf("addresso : %p \n",&a[i]);  
    
  }
  
  return 0;
}
