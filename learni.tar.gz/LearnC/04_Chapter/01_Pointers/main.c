#include<stdio.h>
#include "functions.h"
void ex_1();
void ex_2();

int main (){
    //ex_1();
    
    ex_2();

    return 0;
}

void ex_1(){
    // address and value relations
    // int* ptr_x,x;
    // x = 10;
    // ptr_x = &x;
    // same as above
    int x = 10;
    int* ptr_x = &x;

    printf(" value of           x =  %d \n",x);
    printf(" deref value of ptr_x =  %d \n",*ptr_x);

    printf(" address   of x =  %p \n",&x);
    printf(" value of ptr_x =  %p \n",ptr_x);
    
    for (int i;i <10;++i){
        // these two are same 
        x +=1;
        //*ptr_x +=1;
        printf(" value of           x =  %d \n",x);
        printf(" deref value of ptr_x =  %d \n",*ptr_x);

        printf(" address   of x =  %p \n",&x);
        printf(" value of ptr_x =  %p \n",ptr_x);

    }
}
void ex_2(){
    // struct and pointers
    struct Plane  
    {
        int x;
        int y;
    };
    
    struct Plane my_plane;

    my_plane.x = 1;
    my_plane.y = 2; 
    
    printf("{x = %d, y = %d } \n", my_plane.x,  my_plane.y);

    // a pointer to struct 

    struct Plane*   p_my_plane;
    p_my_plane = &my_plane;

    printf("address of struct %p \n", &my_plane);
    printf("pointer value     %p \n", p_my_plane);


    // change value by derefence of address of struct
    (*p_my_plane).x = 11;
    (*p_my_plane).y = 12; 

    printf("{x = %d, y = %d } \n", my_plane.x,  my_plane.y);





}
