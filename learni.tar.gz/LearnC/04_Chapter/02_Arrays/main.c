#include<stdio.h>
#include "functions.h"

int main (){
    // 1D int array
    int x[3];
    x[0] = 11;
    x[1] = 22;
    x[2] = 33;
    printf("[%d, %d, %d]\n",x[0],x[1],x[2]);
    printf("size of array %ld \n",sizeof(x));
    
    // 2-D ( n-Dimansion)
    int y[3][3];
    



    for (int i=0;i<3;++i){
        
        for (int j=0;j<3;++j){
            printf("[%d, %d]\n",i, j);
            
            y[i][j] = i + j ;
        }
        
    }

    for (int i=0;i<3;++i){
        
        for (int j=0;j<3;++j){
            printf(" y[%d,%d] = %d\n",i,j,y[i][j]);
            
        }
    }
    return 0;
}