#include<stdio.h>
#include "functions.h"
void a_fun(int x );
int main (){
    printf("HELL YA\n");
    int z = 11;
    a_fun(z);
    return 0;
}

void a_fun(int x ){
    printf("x is %d \n",x);
}