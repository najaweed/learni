#include<stdio.h>
#include "functions.h"

// enum Day {
//     Monday=12,     // (defult )= 0 
//     Tuesday,    // (defult )= 1 + value Monday
//     Wednesday,  // (defult )= 2 + value Monday
//     Thursday , // (defult )= 3+ value Monday
//     Friday,     // (defult )= 4 + value Monday

// };
typedef enum{
    Monday=12,     // (defult )= 0 
    Tuesday,    // (defult )= 1 + value Monday
    Wednesday,  // (defult )= 2 + value Monday
    Thursday , // (defult )= 3  + value Monday
    Friday,     // (defult )= 4 + value Monday

}Day;

int main (){
    printf("HELL YA\n");

    Day    d1 = Tuesday;
    Day    d3 = Thursday;
    Day    d4 = Friday;
    printf("d1 = %d\n", d1);
    printf("d3 = %d\n", d3);
    printf("d4 = %d\n", d4);

    return 0;
}