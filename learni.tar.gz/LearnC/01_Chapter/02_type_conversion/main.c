#include<stdio.h>
#include "functions.h"
// program
int main (){
    printf("HELL YA\n");
    printf("type conversion\n");
    
    printf("imiplicit type conversion\n");
    double x = 2.3;
    int    y = x;
    printf("x = %f was double now is = %d int \n", x, y);
    printf("\n");

    printf("explicit type conversion\n");
    int       x1 = 2.3;
    float     y1 = (float)x1;
    printf("x = %d was int now is = %f float \n", x1, y1);
    printf("\n");
    

    return 0;
}