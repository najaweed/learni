#include<stdio.h>
#include "functions.h"

typedef struct
{
    int x;
    float y;
    char z;
} my_struct;

typedef union
{
    int x;
    float y;
    char z;
} my_union;

int main (){
    printf("Program begins\n");
    printf("\n");

    printf("my_struct size = %lu \n",sizeof(my_struct));
    printf("my_union  size = %lu \n",sizeof(my_union));
    printf(" \n");
    
    // union can only save one element at time 
    my_union xuion;

    // change order and see how orders matters in union
    xuion.y = 11.2;
    xuion.x = 12;
    xuion.z = 'b';

    printf("union x = %d \n",xuion.x);
    printf("union y = %f \n",xuion.y);
    printf("union z = %c \n",xuion.z);
    
    printf("\n");
    printf("Program ends\n");
    return 0;
}

