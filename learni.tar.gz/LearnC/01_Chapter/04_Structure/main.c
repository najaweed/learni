#include<stdio.h>
#include "functions.h"


// struct Student
// {
//     float     hight;
//     int          id;
// };
///use as 
//struct Student Kevin;

// struct Student
// {
//     float     hight;
//     int          id;
// } Kevin,John,Mary; define at place 


typedef struct 
{
    float   hight;
    int        id;
} Student ;


int main (){
    printf("HELL YA\n");
    
    //struct Student Kevin;
    Student Kevin;
    Kevin.hight = 190.1;
    Kevin.id    = 111;
    Student John = {180,    123 };
    Student Mary = {.id = 223, .hight = 170  };

    printf("hight = %f  | ",Kevin.hight);
    printf("id = %d \n",Kevin.id);

    printf("hight = %f | ",John.hight);
    printf("id = %d \n",John.id);

    printf("hight = %f | ",Mary.hight);
    printf("id = %d \n",Mary.id);


    return 0;
}