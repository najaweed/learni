#include<stdio.h>
#include "functions.h"

int main (){
    printf("HELL YA\n");

                        int x0;
    short               int x1;
    unsigned            int x2;
    long                int x3;
    long long           int x4;
    unsigned long       int x5;
    unsigned long long  int x6;
    
    printf("\n");
    printf("Integer types\n");
    printf("\n");
    printf("size of                     int = %ld byte\n",sizeof(x0));
    printf("size of short               int = %ld byte\n",sizeof(x1));
    printf("size of unsigned            int = %ld byte\n",sizeof(x2));
    printf("size of long                int = %ld byte\n",sizeof(x3));
    printf("size of long long           int = %ld byte\n",sizeof(x4));
    printf("size of unsigned long       int = %ld byte\n",sizeof(x5));
    printf("size of unsigned long long  int = %ld byte\n",sizeof(x6));
    printf("\n");
    printf("Floating \n");

    float       y0;
    double      y1;
    long double y2;
    printf("size of      float    = %ld byte\n",sizeof(y0));
    printf("size of      double   = %ld byte\n",sizeof(y1));
    printf("size of long double   = %ld byte\n",sizeof(y2));
    printf("\n");
    printf("Charecter\n");
             char   c0;
    signed   char   c1;
    unsigned char   c2;
    printf("size of          char   = %ld byte\n",sizeof(y0));
    printf("size of  signed  char   = %ld byte\n",sizeof(y1));
    printf("size of unsigned char   = %ld byte\n",sizeof(y2));


    return 0;
}