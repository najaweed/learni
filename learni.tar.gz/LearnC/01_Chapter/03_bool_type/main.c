#include<stdio.h>
#include<stdbool.h>
#include "functions.h"

int main (){
    bool x = false;

    printf("bool %d \n",x);
    return 0;
}